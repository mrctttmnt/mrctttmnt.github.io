#!/bin/bash
# NormalizedBingDist_NxN.sh
# This script calculates a Normalized Bing Distance, similar to the Normalized Google
# Distance (Cilibrasi & Vitányi, 2007). See also [Godin, F., De Nies, T., Beecks, C., 
# De Vocht, L., De Neve, W., Mannens, E., … Van De Walle, R. (2014). The Normalized 
# Freebase Distance. Presented at the European Semantic Web Symposium (ESWS) 2014, Crete, 
# Greece] for a similar adaptation.
# v1.7
# Marco Tettamanti, 7.May.2020
# Email: mrctttmnt@gmail.com
#
#
# -----------------------------------------------------------------------------------------
# READ THIS CAREFULLY AND SET CUSTOMIZED VARIABLES !!!
# -----------------------------------------------------------------------------------------
#
# In order to run properly, this script requires:
# - A Bash Unix/Linux shell
# - ELinks text web browser installed on your system (http://elinks.or.cz/):
#   works well with Debian testing 0.13~20190125-5 version, and also with the 
#   Unstable prerelease: elinks-0.12pre6 downloadable from the elinks website.
#   However, in the latter case, you will need to edit 
#   "bing-dot-com-search-commandline" and replace "https" with "http".
# - Bc installed on your system (https://www.gnu.org/software/bc/bc.html, 
#   works well with version bc-1.07.tar.gz).
# - The executable "bing-dot-com-search-commandline" that comes with this script
#   (put it in your path, e.g. in /usr/local/bin). You may need to update the 'sed'
#   replacement expressions cotained in this executable to match
#   current www.bing.com conventions.
# - A separate text file called "WordListN.txt" with one search word per line. Take 
#   particular care of special Unicode characters (see WordList_README.txt).
#
# Customize Bing queries to your search space Country(ies) Region(s) of choice:
# e.g. for Switzerland: CR=\(loc\:CH\)
# Here set by default to U.S. OR Great Britain: CR=\(loc\:US\ \OR\ \loc\:GB\)
CR=\(loc\:US\ \OR\ \loc\:GB\)
#CR=\(loc\:IT\)
#
# Normalizing Factor word (Here by default "the"):
NF=the
#NF=il
#
# Search space Country(ies) Region(s) for Normalizing Factor word:
CRNF=\(loc\:US\ \OR\ \loc\:GB\)
#CRNF=\(loc\:IT\)
#
# Customize Bing hit rate figures separator:
# e.g. full stop "." as in '12.000.000.000'
# or comma "," as in '7010,00,000'
SEP='\.'  # full stop
#SEP=,  # comma
#
# Specify up-to-date numbers within Elinks hit Entry Strings:
# i.e. execute in a bash shell:
# bing-dot-com-search-commandline \+\"the\"
# - Check text output in bash shell and specifically look for
#   the following string before hit rate figure (numbers and text may change):
#   "[12]News"
#   Thus, Elinks Entry String Before is: '\[12\]News'
# - Also look for the following string after hit rate figure:
#   "results[14]Date [15]Language [16]Region" 
#   Thus, Elinks Entry Number After is: 'results\[14\]Date'
EESB='\[12\]News'
EESA='results\[14\]Date'
#
# Specify up-to-date Elinks hit rate Field Number:
# i.e. execute in a bash shell:
# tmpcut=`bing-dot-com-search-commandline \+\"the\"`
# echo $tmpcut |grep $EESB |cut -d " " -f 18-48
# - Try incrementing or decreasing the first number (i.e. 18)
#   until the output begins with the Bing hit rate
#   (e.g. "10.400.000.000 results[14]Date [15]Language")
#   At present, EFN=18:
EFN=18
#
# Specify up-to-date Elinks hit rate Field Number Range:
# This can be confidently set as EFN+40
EFNR=48
#
# Run with command:
# ./NormalizedBingDist_NxN.sh
# -----------------------------------------------------------------------------------------


# case1: ^[14]:
# varaSV=`bing-dot-com-search-commandline \+\"forconi cuscini\"`

# case2: There are no result
# varaSV=`bing-dot-com-search-commandline \+\"laccio fuzziness schande cancun voisin\"`

# case3: 10.400.000.000 results
# varaSV=`bing-dot-com-search-commandline \+\"the\"`


varaSV=`bing-dot-com-search-commandline \+\"$NF\" $CRNF`
varaSV=`echo $varaSV |grep $EESB |cut -d " " -f $EFN-$EFNR | sed -r "s/$SEP//g"`
#case1
if [[ $varaSV = \[14* ]]; then vara=0
#case2
elif [[ $varaSV = *There\ are\ no\ results* ]]; then vara=0
#case3
elif [[ $varaSV = *$EESA* ]]; then vara=`echo $varaSV |cut -d " " -f 1`
fi


# Cycle WordListN (text file with one word per line)
for l1 in `cat WordListN.txt`; do
varbSV=`bing-dot-com-search-commandline \+\"$l1\" $CR`
varbSV=`echo $varbSV |grep $EESB |cut -d " " -f $EFN-$EFNR | sed -r "s/$SEP//g"`
#case1
if [[ $varbSV = \[14* ]]; then varb=0
#case2
elif [[ $varbSV = *There\ are\ no\ results* ]]; then varb=0
#case3
elif [[ $varbSV = *$EESA* ]]; then varb=`echo $varbSV |cut -d " " -f 1`
fi
# Store in temporary text file 'tmpListN.txt'
echo $varb >> tmpListN.txt
# Prevents your automated queries to be locked out by Bing. If this happens, you may need to increase the sleep time interval to e.g. 4s or 6s.
sleep 3s
unset varbSV varb
done


i=0
j=0

for l1 in `cat WordListN.txt`; do
i=$((i+1))
varb=`cat tmpListN.txt | head -$i | tail -1`

for l2 in `cat WordListN.txt`; do
j=$((j+1))

if [[ $j < $i ]]; then continue; fi

varc=`cat tmpListN.txt | head -$j | tail -1`

vardSV=`bing-dot-com-search-commandline \+\"$l1\" \+\"$l2\" $CR`
vardSV=`echo $vardSV |grep $EESB |cut -d " " -f $EFN-$EFNR | sed -r "s/$SEP//g"`
#case1
if [[ $vardSV = \[14* ]]; then vard=0
#case2
elif [[ $vardSV = *There\ are\ no\ results* ]]; then vard=0
#case3
elif [[ $vardSV = *$EESA* ]]; then vard=`echo $vardSV |cut -d " " -f 1`
fi
#fi

if [[ $varb = 0 ]]; then NBD='NULL'
elif [[ $varc = 0 ]]; then NBD='NULL'
elif [[ $vard = 0 ]]; then NBD='INF'

else
logvara=`echo "l($vara)/l(10)" | bc -l`
logvarb=`echo "l($varb)/l(10)" | bc -l`
logvarc=`echo "l($varc)/l(10)" | bc -l`
logvard=`echo "l($vard)/l(10)" | bc -l`

echo $logvarb >> log.tmp
echo $logvarc >> log.tmp
maxlogvarbc=`echo | awk '
function max(x){i=0;for(val in x){if(i<=x[val]){i=x[val];}}return i;}
{a[$1]=$1;next}
END{maximum=max(a);print maximum}' log.tmp`
minlogvarbc=`echo | awk '
function max(x){i=0;for(val in x){if(i<=x[val]){i=x[val];}}return i;}
function min(x){i=max(x);for(val in x){if(i>x[val]){i=x[val];}}return i;}
{a[$1]=$1;next}
END{minimum=min(a);print minimum}' log.tmp`
rm log.tmp

NBD=`echo "($maxlogvarbc- $logvard)/($logvara- $minlogvarbc)" | bc -l`
fi

# Store in text file 'NormalizedBingDistNxN.output' (can be opened in LibreOffice Calc)
echo $l1$'\t'$varb$'\t'$l2$'\t'$varc$'\t'$l1+$l2$'\t'$vard$'\t'$NF$'\t'$vara$'\t'NBD\($l1+$l2\)$'\t'$NBD >> NormalizedBingDistNxN.output

unset varc vardSV vard logvarc logvard maxlogvarbc minlogvarbc NBD
sleep 3s
done
echo >> NormalizedBingDistNxN.output
unset varb logvarb
j=0
done

rm tmpListN.txt
