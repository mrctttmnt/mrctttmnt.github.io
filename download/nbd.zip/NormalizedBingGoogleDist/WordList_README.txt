# WordList_README.txt
# v1.7
# Marco Tettamanti, 7.May.2020
# Email: mrctttmnt@gmail.com

If you have words with special Unicode characters (e.g., according to https://en.wikipedia.org/wiki/List_of_Unicode_characters#Phonetic_scripts), proceed as follows:

1) Open www.bing.com in your browser (works with Firefox):

2) In the search box, type your critical word, together with your search space Country(ies) Region(s) of choice, e.g.:

+<libertà> loc:IT

3) After the search has been carried out, use the Source Visualization tool in your browser (e.g. Ctrl+U in Firefox) to open the source page of the obtained results.

4) In line 3 of the source page, you should find the following output:

//]]></script><head><!--pc--><title>+&lt;libert&#224;&gt; loc:IT - Bing</title><meta content="text/html; charset=utf-8" http-equiv="content-type" /><meta name="referrer" content="origin-when-cross-origin" /><link href="/search?format=rss&amp;q=%2B%3Clibert%C3%A0%3E+loc%3AIT&amp;form=QBLH&amp;sp=-1&amp;pq=%2B%3Clibert%C3%A0%3E+loc%3Ait&amp;sc=0-17&amp;qs=n&amp;sk=&amp;cvid=3B09573B0F3C4E2D8F3BC58DAAFDBECE" rel="alternate" title="XML" type="text/xml" /><link href="/search?format=rss&amp;q=%2B%3Clibert%C3%A0%3E+loc%3AIT&amp;form=QBLH&amp;sp=-1&amp;pq=%2B%3Clibert%C3%A0%3E+loc%3Ait&amp;sc=0-17&amp;qs=n&amp;sk=&amp;cvid=3B09573B0F3C4E2D8F3BC58DAAFDBECE" rel="alternate" title="RSS" type="application/rss+xml" /><link href="/sa/simg/bing_p_rr_teal_min.ico" rel="shortcut icon" /><script type="text/javascript">//<![CDATA[

5) From left to right, look for the first "href" statements. In this particular example:

href="/search?format=rss&amp;q=%2B%3Clibert%C3%A0%3E+loc%3AIT

6) Now isolate the part of the string that follows "href="/search?format=rss&amp;q=". In this particular example:

%2B%3Clibert%C3%A0%3E+loc%3AIT

7) Finally, eliminate the onset (%2B) and the end (+loc%3AIT) parts. In this particular example, you will be left with:

%3Clibert%C3%A0%3E

This is the string you will have to enter in your "WordListN.txt" or "WordListM.txt", as a replacement of your critical word.
