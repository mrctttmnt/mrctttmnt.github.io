PLEASE READ THIS CAREFULLY

By using this code, you agree to the following terms:

Permission is granted to copy, distribute and/or modify this code under the terms of the Creative Commons Attribution-ShareAlike 4.0 International Public License (http://creativecommons.org/licenses/by-sa/4.0/legalcode) or any later version published by Creative Commons.


2015-2020, Marco Tettamanti
