PLEASE READ THIS CAREFULLY

By downloading the set of sentence stimuli, you and your coworkers agree to the following terms:

1) Permission is granted to copy, distribute and/or modify this set of sentence stimuli under the terms of the Creative Commons Attribution-ShareAlike 4.0 International Public License (http://creativecommons.org/licenses/by-sa/4.0/legalcode) or any later version published by Creative Commons.
See also http://creativecommons.org/licenses/by-sa/4.0/ for a summary and the attached GhioMetal_PONE2013_CCASA4.0-IPL.txt file.

2) Please refer to the use of this set of sentence stimuli in your manuscript by citing:
Ghio, M., Vaghi, M. M. S., & Tettamanti, M. (2013). Fine-Grained Semantic Categorization across the Abstract and Concrete Domains. PLoS ONE, 8(6), e67090. doi:10.1371/journal.pone.0067090


Best of luck with your research!
Marta Ghio, Matilde M.S. Vaghi, Marco Tettamanti
